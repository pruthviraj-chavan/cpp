/*
 *  Transmit a status message whenever the browser action icon is clicked. This may be used by a background script as a
 *  signal from the user to recreate, or make active, a tab in use by the background script, or for other purposes.
 *  Other interaction with a user is possible only through a content script on a browser tab.
 */

function browserAction(){
  const self = 'Browser action';
  Hub.register.call(self);
  browser.browserAction.onClicked.addListener(actionClicked);

  function actionClicked(){
    Hub.transmitStatus.call(self, 'Clicked');
  }
}


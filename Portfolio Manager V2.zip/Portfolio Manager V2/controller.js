/*
 *  Tool for tracking dividend payments over one or more trading stock accounts
 *  The user may start with an existing portfolio or create a new portfolio using TD account holding CSV files
 *  An existing portfolio may also be updated using TD account holding CSV files
 *  Generated files are stored using Firefox's using default download folder as the root folder
 *  Only one account will be shown at a time with the number of holdings fixed for each account
 *  The account row ordering will change depending on the sorting criteria selected
 *  Account dividend elements are fixed, but values will change when the dividend payment schedule changes
 *  Dividend payment schedule elements are fixed, but the element values will change
 *  Changes in account holdings can only add companies to the dividend schedule, companies are never removed
 *  When any part of the dividend schedule changes, dividend metrics for each account and the portfolio will be updated
 *  A master account, 'All', containing all holdings of all accounts is also created
 *  Clicking on the browser action icon will make the user interface page active, recreating the page if necessary
 *  If the page content script will be changed, it's necessary to remove and recreate the tab
 */

function controller(){
  //Show initial screen for downloading an existing portfolio or for creating a new portfolio from account CSV files
  const fileReader = new FileReader(), self = 'Controller';
  Hub.register.call(self);
  //Create bridge between user interface page and background script
  Hub.transmitRequest('Bridge', 'Register', 'User interface');
  let selectedFiles, fileIndex = 0, accountFiles,  selectedAccount, accounts, portfolio, schedule = {};
  let errorMessage = null, tabParameters, pageParameters;

  function initialize(){
    Hub.bindRequest.call(self, 'Get portfolio', getPortfolio);
    Hub.bindStatus.call(self, 'User interface', 'Files', receiveFiles);
    Hub.bindStatus.call(self, 'User interface', 'Set portfolio', setPortfolio);
    Hub.bindRequest.call(self, 'Save portfolio', savePortfolio);
    Hub.bindRequest.call(self, 'Update portfolio', displayUpdatePage);
    Hub.bindStatus.call(self, 'Browser action', 'Clicked', displayUserInterface);
  }
  
  function getPortfolio(){
    //Display initial user interface page
    tabParameters = {
      'Page URL':'file selection/file-selection.html',
      'Content script':'file selection/file-selection.js',
      'Active tab':true
    };
    pageParameters = {
      'User prompt':'Drag and drop account files or portfolio here',
      'Error message':errorMessage,
      'Multiple file':true,
      //Single file may be account holdings CSV file or previously save portfolio
      'Single mime types':['text/csv', 'application/json'],
      //Multiple files may only be account holdings CSV files
      'Multiple mime types':['text/csv']
    };
    Hub.bindStatus.call(self, 'User interface', 'Files', receiveFiles);
    Hub.transmitRequest(
      'User interface', 'Display page', {'Page parameters':pageParameters, 'Tab parameters':tabParameters}
    );
  }
  
  function displayPortfolioPage(){
    //Display current portfolio on user interface page
    tabParameters = {
      'Page URL':'display/portfolio.html',
      'Content script':'display/portfolio.js',
      'Active tab':true
    };
    pageParameters = {'Portfolio':portfolio};
    Hub.transmitRequest(
      'User interface', 'Display page', {'Page parameters':pageParameters, 'Tab parameters':tabParameters}
    );
  }

  function displayUpdatePage(){
    //Remove all accounts from portfolio, while retaining dividend schedule
    tabParameters = {
      'Page URL':'file selection/file-selection.html',
      'Content script':'file selection/file-selection.js',
      'Active tab':true
    };
    pageParameters = {
      'User prompt':'Drag and drop account files here',
      'Error message':errorMessage,
      'Multiple file':true,
      //Only account holdings CSV files may be used for updating portfolio
      'Single mime types':['text/csv'],
      'Multiple mime types':['text/csv'],
      'Sender name':'User interface'
    };
    Hub.transmitRequest(
      'User interface', 'Display page', {'Page parameters':pageParameters, 'Tab parameters':tabParameters}
    );
  }
  
  function displayUserInterface(){
    //Redisplay current user interface page
    Hub.transmitRequest(
      'User interface', 'Display page', {'Page parameters':pageParameters, 'Tab parameters':tabParameters}
    );  
  }
  
  function receiveFiles(payload){
    //Receive a new portfolio either as one or more CSV account files or a single JSON portfolio file
    selectedFiles = payload, portfolio = {}, accounts = {}, selectedAccount = 'All', accountFiles = [];
    if(selectedFiles.length === 1){
      //Receive portfolio or single account file
      if(selectedFiles[0].type === 'application/json'){
        //Read portfolio file
        fileReader.onloadend = portfolioRead;
        fileReader.readAsText(selectedFiles[0]);
      }else if(selectedFiles[0].type === 'text/csv'){
        //Read single account file
        fileReader.onloadend = readNextAccount;
        fileReader.readAsText(selectedFiles[0]);
      }else{
        //Wrong file type for accounts or portfolio upload
        errorMessage = 'File type must be CSV or JSON';
        displayUserInterface();
      }
    }else{
      //Receive multiple account files
      fileIndex = 0;
      fileReader.onloadend = readNextAccount;
      fileReader.readAsText(selectedFiles[fileIndex]);
    }
  }

  function readNextAccount(){
    //Continue reading account files
    if(fileReader.error === null){
      accountFiles.push(fileReader.result);
      fileIndex ++;
      if(fileIndex < selectedFiles.length){
        fileReader.readAsText(selectedFiles[fileIndex]);
      }else{
        //All account files read
        let combinedHoldings = [], account;
        for(let accountFile of accountFiles){
          //Extract account data from CSV file
          const fileData = readCSVfile(accountFile);
          const accountNumber = fileData[1][1].split(" - ")[1]
          const rawHoldings = fileData.slice(8);
          accounts[accountNumber] = buildAccount(accountNumber, rawHoldings);
          combinedHoldings = combinedHoldings.concat(rawHoldings);
        }
        //Generate master account by combining holdings of all accounts
        accounts['All'] = buildAccount('All', combinedHoldings);
        //Send completed portfolio to user interface
        portfolio['Schedule'] = schedule;
        portfolio['Accounts'] = accounts;
        portfolio['Selected account'] = 'All';
        displayPortfolioPage();
      }
    }else{
      //Send error message to user interface
      errorMessage = 'File read error:' + fileReader.error;
      getPortfolio();
    }
  }
  
  function buildAccount(accountNumber, rawHoldings){
    //Build account client using CSV file containing account holdings as source
    let totalBookValue = 0, totalMarketValue = 0, key;
    const holdings = {}, rowOrder = [];
    const account = {'Account number':accountNumber, 'Holdings':holdings, 'Row order':rowOrder};
    for(let fileRow of rawHoldings){
      //Company must have stock symbol to be valid
      if(fileRow[0].length > 0){
        const symbol = fileRow[0], exchange = fileRow[1];
        //Because a stock symbol may not be unique, concatenate with exchange to create a unique identifier
        const key = symbol.concat(' ', exchange);
        if(rowOrder.includes(key) === false){
          //Update dividend schedule with possible new company
          addCompany(key);
          rowOrder.push(key);
          const holding = {};
          holdings[key] = holding;
          holding['Symbol'] = symbol;
          holding['Exchange'] = fileRow[1];
          holding['Moniker'] = fileRow[2];
          holding['Quantity'] = Number.parseInt(fileRow[3], 10);
          holding['Book value'] = Number.parseFloat(fileRow[6], 10);
          totalBookValue += holding['Book value'];
          holding['Market value'] = Number.parseFloat(fileRow[7], 10);
          totalMarketValue += holding['Market value'];
        }else{
          //Account is 'All' with multiples of same holding
          holding = holdings[key];
          holding['Quantity'] += Number.parseInt(fileRow[3], 10);
          const bookValue = Number.parseFloat(fileRow[6], 10);
          holding['Book value'] += bookValue;
          totalBookValue += bookValue;
          const marketValue = Number.parseFloat(fileRow[7], 10);
          holding['Market value'] += marketValue
          totalMarketValue += marketValue;
        }
      }
    }
    account['Total book value'] = totalBookValue;
    account['Total market value'] = totalMarketValue;
    //Calculate share statistics based on total account values
    for(let key of rowOrder){
      const holding = holdings[key];
      holding['Percent book value'] = holding['Book value'] / totalBookValue;
      holding['Percent market value'] = holding['Market value'] / totalBookValue;
    }
    return account;
  }
  
  function addCompany(key){
    //Add company to dividend payment schedule if not currently present
    if(key in schedule === false){
      const payDates = {
     	  'january':null,
     	  'february':null,
     	  'march':null,
     	  'april':null,
     	  'may':null,
     	  'june':null,
     	  'july':null,
     	  'august':null,
     	  'september':null,
     	  'october':null,
     	  'november':null,
     	  'december':null
	    };
	    const confirmations = {
     	  'january':false,
     	  'february':false,
     	  'march':false,
     	  'april':false,
     	  'may':false,
     	  'june':false,
     	  'july':false,
     	  'august':false,
     	  'september':false,
     	  'october':false,
     	  'november':false,
     	  'december':false
     	};
	    schedule[key] = {'Pay dates':payDates, 'Confirmations': confirmations, 'Payment':0};
    }
  }

  function portfolioRead(){
    //Only one portfolio file may be read
    if(fileReader.error === null){
      try{
        portfolio = JSON.parse(fileReader.result);
        schedule = portfolio['Schedule'];
      }catch(error){
        logError(error);
        errorMessage = error;
        getPortfolio();
      }
      displayPortfolioPage();
    }else{
      logError(error);
      errorMessage = error;
      getPortfolio();
    }
  }
  
  function setPortfolio(payload){
    //Receive updated portfolio from user interface
    portfolio = payload;
    schedule = portfolio['Schedule'];
  }

  function savePortfolio(){
    //Download portfolio to default download folder
    browser.downloads.download(
    {url:URL.createObjectURL(new Blob([JSON.stringify(portfolio)], {type : 'text/html'})),
     filename:'Portfolio/portfolio.json',
     conflictAction:"overwrite"}
    ).catch(logError);
  }

  function logError(error){
    Hub.transmitRequest('Error logger', 'Log error', error);
  }

  return{initialize:initialize};
}


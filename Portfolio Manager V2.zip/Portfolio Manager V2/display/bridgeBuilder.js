/*
 *  A bridge is an interposing object used to make a content script appear as a hub client to the background script.
 *  Prior to use, a bridge name must be registered with the bridge builder. The bridge builder will then register the
 *  name with the hub so that interaction will be possible with all other hub clients.
 *  Bridge names must be unique both to other bridges and hub clients. An error will be thrown for name conflicts.
 *  A bridge will respond to five requests, 'Display page', 'Send message', 'Remove page', 'Remove all' and 'Expunge'.
 *  The 'Display page' request will always remove an existing tab, create an new tab and upload the page to it. This is
 *  necessary because content scripts once loaded, cannot be overwritten. Loading a content script into a tab with a
 *  previously loaded script will cause function name collisions and unexpected behavior.
 *  The 'Send message' request is used to send only page content. If the receiving tab doesn't exist the bridge will not
 *  create it. When a tab is removed, a status signal will be sent and it is a client's responsibility to decide if and
 *  under what circumstances to send a 'Display page' request to recreate the tab and page.
 *  The browser action icon is monitored by a dedicated hub client and will transmit a status message whenever the icon
 *  is clicked. A client can use this as a signal to create the tab and display the page to the user.
 *  If the page is being used to access the internet, a watchdog timer or similar means can be used to force a tab
 *  re-creation if there is no response because of tab removal.
 *  The 'Remove page' request will remove tab associated with client name.
 *  The 'Broadcast' request will transmit a request to all hub clients, in both background and content script contexts
 *  and is intended for orderly application shutdown initiated by a user interface page.
 *  The 'Expunge' request will completely delete a client from both the hub and bridge. It's main intent is for name and
 *  memory reuse.
 *  Messages from the content script will be an object containing the message type: request, status or broadcast,
 *  sending client name for a status message, receiving client name, message tag and optional payload.
 *  The bridge will re-format the message according to the type and then forward it to the hub for transmission to a
 *  client or clients.
 *  Messages sent from the background script to the content script are sent unchanged.
 *  When a tab that the bridge is connected to is removed, the bridge will transmit a 'Tab removed' status signal
 *  with the bridge name passed as 'this'.
 *  Multiple bridges and tabs may be active simultaneously.
 */
function bridgeBuilder(){
  const self = 'Bridge', pages = {};
  Hub.register.call(self);
  
  function initialize(){
    Hub.bindRequest.call(self, 'Register', register);
    Hub.bindRequest.call(self, 'Remove all', removeAll);
    browser.tabs.onRemoved.addListener(tabRemoved);
    browser.tabs.onUpdated.addListener(tabUpdated);
  }
  
  function register(bridgeName){
    bridgeName = String(bridgeName);  //Bridge instance name may be string primitive
    if(bridgeName in pages){
      fail(Error('Bridge instance name '.concat(bridgeName, ' previously registered')));
    }else{
      //Register bridge instance as hub client to allow interaction with other hub clients
      try{
        Hub.register.call(bridgeName);
        pages[bridgeName] = {
          'self':bridgeName, 'Tab parameters':null, 'Page parameters':null, 'Tab ID':null, 'Port':null
        };
        Hub.bindRequest.call(bridgeName, 'Display page', displayPage);
        Hub.bindRequest.call(bridgeName, 'Send message', sendMessage);
        Hub.bindRequest.call(bridgeName, 'Remove', remove);
        Hub.bindRequest.call(bridgeName, 'Expunge', expunge);
      }catch(error){
        fail(error);
      }
    }
  }
  
  function displayPage(payload){
    //Note that message is received from hub as hub formatted message
    //Because the content script may be changed when a new page is displayed, the tab must be removed to clear the
    //existing content script. Loading a new content script into a tab with an existing content script may result in
    //unexpected behavior.
    //Tab presence or absence is not important because a tab can be removed at any time. Because of this, the full tab
    //creation and page content information must always be passed to this method to fully recreate the tab and page.
    const bridgeName = this['receiver'];
    const bridge = pages[bridgeName];
    try{
      if(bridge === undefined){
        throw Error('Bridge '.concat(bridgeName, ' has not been registered'));
      }
      //Tab parameters must exist to create page
      const tabParameters = payload['Tab parameters'];
      const pageParameters = payload['Page parameters']
      if(tabParameters === undefined || tabParameters === null){
        throw Error('Undefined tab parameters for bridge instance name '.concat(bridgeName));
      }
      bridge['Tab parameters'] = tabParameters;
      const pageURL = tabParameters['Page URL'];
      if(pageURL === undefined){
        throw Error('Undefined page URL for bridge instance name '.concat(bridgeName));
      }
      bridge['Page URL'] = pageURL;
      if(pageParameters === undefined || pageParameters === null){
        //Page parameters are required for sending hub client name
        bridge['Page parameters'] = {'self':bridgeName};
      }else{
        bridge['Page parameters'] = pageParameters;
        bridge['Page parameters']['self'] = bridgeName;
      }
      const tabID = bridge['Tab ID'];
      if(tabID === undefined){
        bridge['Tab ID'] = null;
        bridge['Port'] = null;
      }
      if(bridge['Tab parameters']['Active tab'] === undefined){
        bridge['Tab parameters']['Active tab'] = false;
      }
      if(Number.isInteger(tabID)){
        //Tab may or may not exist, attempt to remove it and then re-create it
        browser.tabs.remove(tabID).then(createTab.bind(bridgeName), createTab.bind(bridgeName));
      }else{
        createTab.call(bridgeName);
      }
    }catch(error){
      fail(error);
    }
  }
  
  function createTab(){
    //Bridge name passed as 'this'
    const bridge = pages[this];
    browser.tabs.create({url:bridge['Page URL'], active:bridge['Active tab']}).then(tabCreated.bind(this), fail);
  }

  function tabCreated(tabInfo){
    //Tab creation completed, 'this' contains page name
    const bridge = pages[this];
    bridge['Tab ID'] = tabInfo.id;
    const scriptPath = bridge['Tab parameters']['Content script'];
    //By default, script will run after tab loading is complete
    if(scriptPath !== undefined){
		  browser.tabs.executeScript(bridge['Tab ID'], {file:scriptPath}).then(connectToTab.bind(this), fail);
    }
  }

  function connectToTab(){
    //Connect to content script on tab, 'this' contains page name
    const bridge = pages[this];
	  try{
	    const port = browser.tabs.connect(bridge['Tab ID']);
	    bridge['Port'] = port;
	    port.onMessage.addListener(forward);
      port.postMessage(bridge['Page parameters']);
	  }catch(error){
		  fail(error);
	  }
  }
  
  function sendMessage(payload){
    //Send message from background script to content script. Tab will not be created if it doesn't exist. Instead, an
    //error status signal will be transmitted. If the message must be sent, the sending client must be subscribed to
    //the error status signal and send a Display page request to deliver the message.
    //Note that message is received from hub as a hub formatted message.
    const bridgeName = this['receiver'];
    const bridge = pages[bridgeName];
    if(bridge !== undefined && Number.isInteger(bridge['Tab ID'])){
      try{
        bridge['Port'].postMessage({'self':bridgeName, 'Message':payload});
      }catch(error){
        Hub.transmitStatus.call(bridgeName, 'Send failed', error);
      }
    }else{
      Hub.transmitStatus.call(bridgeName, 'Send failed', 'Non-existent tab');
    }
  }
  
  function tabRemoved(tabId, removeInfo){
    //Transmit status signal when bridge tab is removed
    for(let bridgeName in pages){
      bridge = pages[bridgeName]
      if(bridge['Tab ID'] === tabId){
        bridge['Tab ID'] = null;
        bridge['Port'] = null;
        Hub.transmitStatus.call(bridge[self], 'Tab removed');
      }
    }
  }
  
  function tabUpdated(tabId, changeInfo){
    //If tab ID matches a client's ID, transmit a status signal after page loading has completed
    if(changeInfo.status === 'complete'){
      for(let bridgeName in pages){
        const bridge = pages[bridgeName];
        const bridgeTabID = bridge['Tab ID'];
        if(Number.isInteger(tabId) && tabId === bridgeTabID){
          Hub.transmitStatus.call(bridgeName, 'Tab updated', changeInfo);
          break;
        }
      }
    }
  }

  function forward(message){
    //Receive message from content script and then forward as a Hub client message
    const messageType = message['Message type'];
    if(messageType === 'Status'){
      //Forward message from content script as a Hub status message
      Hub.transmitStatus.call(message['self'], message['Message'], message['Payload']);
    }else if(messageType === 'Request'){
      //Forward message from content script as Hub request message
      Hub.transmitRequest(message['Receiver'], message['Message'], message['Payload']);
    }else if(messageType === 'Broadcast'){
      //Forward message from content script as Hub broadcast message
      Hub.broadcast(message['Message'], message['Payload']);
    }else{
      Hub.transmitRequest(
        'Error logger', 'Log error', Error('Unknown message type received from content script: ' + messageType)
      );
    }
  }

  function remove(payload){
    //Note that message is received from hub as hub formatted message
    //Page tab will be removed, but bridge will remain as hub client
    const bridgeName = this['receiver'];
    const bridge = pages[bridgeName];
    if(bridge !== undefined && Number.isInteger(bridge['Tab ID'])){
      browser.tabs.remove(bridge['Tab ID']);
    }
  }

  function removeAll(){
    //Remove all registered bridge tabs
    for(let bridgeName in pages){
      remove.call(bridgeName);
    }
  }
  
  function expunge(){
    //Note that message is received from hub as a hub formatted message
    //Remove bridge name as both bridge and hub client
    const bridgeName = this['receiver'];
    if(pages[bridgeName] !== undefined){
      //Format as hub message
      remove.call({'receiver':bridgeName});
      pages.delete(bridgeName);
      hub.expunge(bridgeName);
    }
  }

  function fail(error){
    Hub.transmitRequest('Error logger', 'Log error', error);
  }
   
  return {initialize:initialize};
}

/*
 *  Content script for building and managing portfolio display
 *  Accounts, dividend schedule and holding row order are sent from the controller with user modifications sent back to
 *  the controller for archiving.
 */

function connect(backgroundPort){
  const port = backgroundPort;
  let self, selectedAccount, accounts, schedule, paymentIDs, dateIDs, sortTarget, holdings, rowOrder;
  port.onMessage.addListener(messageHandler);

  function messageHandler(payload){
    if(payload === undefined){
      fail(Error('Undefined payload received by portfolio content script'));
    }else{
      self = payload['self'];
      if(self === undefined){
        fail(Error("'self' not received by portfolio content script"));
      }
      portfolio = payload['Portfolio'];
      accounts = portfolio['Accounts'];
      selectedAccount = portfolio['Selected account'];
      schedule = portfolio['Schedule'];
      displayAccountSelectors();
      refreshAccount();
      bindButtonHandlers();
      bindSortHandlers();
    }
  }
  
  function sendStatus(message, payload){
    port.postMessage(
      {
        'self':self,
        'Message type':'Status',
        'Message':message,
        'Payload':payload
      }
    );
  }
  
  function sendRequest(receiver, message, payload){
    port.postMessage(
      {
        'self':self,
        'Message type':'Request',
        'Receiver':receiver,
        'Message':message,
        'Payload':payload
      }
    );
  }
  
  function fail(error){
    port.postMessage(
      {
        'self':self,
        'Receiver name':'Error logger',
        'Message type':'Request',
        'Message':'Log error',
        'Payload':error
      }
    );
  }

  function updateAccountDividends(){
    //Update dividend data for companies in each account when dividend schedule is changed
    let totalHoldingDividend = 0, totalAccountDividend = 0;
    for(let accountNumber in accounts){
      const account = accounts[accountNumber];
      const holdings = account['Holdings'];
      const monthlyPayments = {};
      for(let month of MONTHS){
        monthlyPayments[month] = 0;
      }
      for(let key of account['Row order']){
        const holding = holdings[key];
        const quantity = holding['Quantity'];
        const paymentSchedule = schedule[key];
        if(paymentSchedule !== undefined){
          //Calculate total yearly dividend
          const payDates = paymentSchedule['Pay dates'];
          const payment = paymentSchedule['Payment'];
          totalHoldingDividend = 0;
          for(let month in payDates){
            payDate = payDates[month];
            if(Number.isInteger(payDate) && payDate > 0){
              totalHoldingDividend += payment;
              monthlyPayments[month] += payment * quantity;
            }
          }
          totalHoldingDividend = totalHoldingDividend * quantity;
          holding['Total dividend'] = totalHoldingDividend;
          totalAccountDividend += totalHoldingDividend;
        }
      }
      account['Total dividend'] = totalAccountDividend;
      account['Monthly payments'] = monthlyPayments;
    }
    //Calculate dividend metrics for each holding and account
    for(let accountNumber in accounts){
      const account = accounts[accountNumber];
      const holdings = account['Holdings'];
      const totalAccountDividend = account['Total dividend'];
      for(let key of account['Row order']){
        const holding = holdings[key];
        if(holding['Total dividend'] > 0){
          holding['Percent dividend'] = holding['Total dividend'] / totalAccountDividend;
        }else{
          holding['Percent dividend'] = 0;
        }
      }
    }
  }

  function displayAccountSelectors(){
    const accountSelectors = document.getElementById('account-selectors');
    let selectorHTML = '<td class="normal">Select account: </td>';
    console.log('Accounts', accounts);
    for(let accountNumber in accounts){
      console.log('Got here 11');
      const identifier = 'select-'.concat(accountNumber);
      selectorHTML = selectorHTML.concat(
        '<td><span class="normal">',
        accountNumber,
        '<input type="radio" id="',
        identifier,
        '" name="account-select" value="',
        accountNumber,
        '" checked="false"></span></td>'
      );
    }
    accountSelectors.insertAdjacentHTML("beforeend", selectorHTML);
    document.getElementById('select-'.concat(selectedAccount)).checked = true;
    for(let accountNumber in accounts){
      console.log('Got here 12');
      const identifier = 'select-'.concat(accountNumber);
	    document.getElementById(identifier).addEventListener('change', accountSelectionChanged);
	  }
  }

  function accountSelectionChanged(event){
    //Delete HTML for currently displayed account and then display new account
    const accountNumber = event.target.id.split('-')[1];
    selectedAccount = accountNumber;
    refreshAccount()
  }

  function refreshAccount(){
	  const account = accounts[selectedAccount];
	  if(dateIDs != undefined && dateIDs != null){
      releaseDateHandlers(dateIDs);
    };
    if(paymentIDs != undefined && paymentIDs != null){
      releasePaymentHandlers(paymentIDs);
    };
	  clearAccount();
	  clearTotals();
	  updateAccountDividends();
	  displayAccount(account);
	  displayTotals(account);
	  bindPaymentHandlers(paymentIDs);
    bindDateHandlers(dateIDs);
    sendStatus('Set portfolio', portfolio);
  }

  function displayAccount(account){
    //Display selected account in current sort order
    const accountContainer = document.getElementById("company-rows");
    let rowHTML;
    const holdings = account['Holdings'];
    rowOrder = account['Row order'];
    paymentIDs = [];
    dateIDs = [];
    for(let index in rowOrder){
      //Alternate background colors for better visibility
      if(index % 2 === 0){
        rowHTML = '<tr class="even-row">';
      }else{
        rowHTML = '<tr class="odd-row">';
      }
      const key = rowOrder[index];
      const holding = holdings[key];
      //Populate company data columns
      rowHTML = rowHTML.concat(
       '<td class="normal">', holding["Symbol"], '</td>',
       '<td class="normal">', holding["Exchange"], '</td>',
       '<td class="normal">', holding["Moniker"], '</td>',
       '<td class="normal">', integerFormat(holding["Quantity"]), '</td>',
       '<td class="normal">', currencyFormat(holding["Book value"]), '</td>',
       '<td class="normal">', currencyFormat(holding["Market value"]), '</td>',
       '<td class="normal">', percentFormat(holding["Percent book value"]), '</td>',
       '<td class="normal">', percentFormat(holding["Percent market value"]), '</td>',
       '<td class="normal">', currencyFormat(holding["Total dividend"]), '</td>',
       '<td class="normal">', percentFormat(holding["Percent dividend"]), '</td>'
      );
      let calendar = schedule[key];
      //Populate dividend payment column
      paymentIDs.push(key);
      let payment = calendar['Payment'], cssClass;
      if(Number.isFinite(payment) && payment > 0){
        payment = currencyFormat(payment);
        cssClass = 'dividend-payment active';
      }else if(payment === null || payment === 0 || payment === undefined){
        payment = '';
        cssClass = 'dividend-payment active';
      }else{
        cssClass = 'dividend-payment active bad-input';
      }
      rowHTML = rowHTML.concat(
        '<td class="',
        cssClass,
        '"><input type="text" id="',
        key,
        '" value="',
        payment,
        '" class = "',
        cssClass,
        '"/></td>'
      );
      //Populate dividend date columns
      for(let index = 0; index < MONTHS.length; index ++){
        const month = MONTHS[index];
        const dateIdentifier = key.concat('-', month);
        let cssClass;
        dateIDs.push(dateIdentifier);
        let dividendDate = calendar['Pay dates'][month];
        if(Number.isInteger(dividendDate) && dividendDate > 0){
          dividendDate = integerFormat(dividendDate);
          if(calendar['Confirmations'][month] === true){
            cssClass = 'dividend-date active confirmed';
          }else{
            cssClass = 'dividend-date active tentative';
          }
        }else if(dividendDate === null){
          dividendDate = '';
          cssClass = 'dividend-date active tentative';
        }else{
          cssClass = 'dividend-date active bad-input';
        }
        rowHTML = rowHTML.concat(
          '<td class="dividend-date"><input type="text" id="',
          dateIdentifier,
          '" value="',
          dividendDate,
          '" class="',
          cssClass,
          '"></td>'
        );
      }
      rowHTML = rowHTML.concat('</tr>');
      accountContainer.insertAdjacentHTML("beforeend", rowHTML);
    }
    //Add final row to show monthly dividend payments
    rowHTML = '<tr>';
    for(let blankColumn = 0; blankColumn < 11; blankColumn ++){
      rowHTML = rowHTML.concat('<td class="normal">   </td>');
    }
    const monthlyPayments = account['Monthly payments'];
    for(let month of MONTHS){
      rowHTML = rowHTML.concat('<td class="normal">', currencyFormat(monthlyPayments[month]), '</td>');
    }
    rowHTML = rowHTML.concat('</tr>');
    accountContainer.insertAdjacentHTML("beforeend", rowHTML);
  }

  function clearAccount(){
    const accountContainer = document.getElementById('company-rows');
    while(accountContainer.childNodes.length > 0){
		  accountContainer.removeChild(accountContainer.childNodes[0]);
	  }
  }

  function displayTotals(account){
    //Show totals of account holdings
    const summaryContainer = document.getElementById("account-summary");
    let totalHTML = '<td class="normal column-title">Total market value: '.concat(
      currencyFormat(account['Total market value']), '</td>'
    );
    summaryContainer.insertAdjacentHTML("beforeend", totalHTML);
    totalHTML = '<td class="normal column-title">Total book value: '.concat(
      currencyFormat(account['Total book value']), '</td>'
    );
    summaryContainer.insertAdjacentHTML('beforeend', totalHTML);
    totalHTML = '<td class="normal column-title">Total dividend '.concat(
      currencyFormat(account['Total dividend']), '</td>'
    );
    summaryContainer.insertAdjacentHTML('beforeend', totalHTML);
  }

  function clearTotals(){
    const summaryContainer = document.getElementById("account-summary");
    while(summaryContainer.childNodes.length > 0){
		  summaryContainer.removeChild(summaryContainer.childNodes[0]);
	  }
  }

  function bindPaymentHandlers(identifiers){
    for(identifier of identifiers){
      const element = document.getElementById(identifier);
      element.addEventListener("change", paymentSet);
    }
  }

  function releasePaymentHandlers(identifiers){
    for(identifier of identifiers){
      const element = document.getElementById(identifier);
      element.removeEventListener("change", paymentSet);
    }
  }

  function paymentSet(event){
    //Check and set dividend payment amount with bad input indicated by a red background
    const elementIDparts = event.target.id.split('-');
    const key = elementIDparts[0];
    const element = document.getElementById(event.target.id);
    const payment = Number.parseFloat(element.value);
    if(Number.isFinite(payment) && payment > 0){
      element.value = currencyFormat(payment);
    }else if(element.value === '' || element.value === 0 || element.value === null || element.value === undefined){
      element.value = '';
      payment = null;
    }else{
      payment = element.value;
    }
    schedule[key]['Payment'] = payment;
    refreshAccount();
  }

  function bindDateHandlers(identifiers){
    for(identifier of identifiers){
      const element = document.getElementById(identifier);
      element.addEventListener("change", dateSet);
      element.addEventListener("contextmenu", toggleConfirm);
    }  
  }

  function releaseDateHandlers(identifiers){
    for(identifier of identifiers){
      const element = document.getElementById(identifier);
      element.removeEventListener("change", dateSet);
      element.removeEventListener("contextmenu", toggleConfirm);
    }  
  }

  function dateSet(event){
    //Check and set dividend date with bad input indicated by a red background
    //A confirmed date is indicated by a green background
    const elementIDparts = event.target.id.split('-');
    const key = elementIDparts[0];
    const month = elementIDparts[1];
    const element = document.getElementById(event.target.id);
    const cssClass = element.getAttribute("class");
    let date = Number.parseInt(element.value);
    if(Number.isInteger(date) && date > 0 && date <= DATE_LIMITS[month]){
      element.value = date;
      element.setAttribute('class', 'dividend-date tentative');
    }else if(element.value === '' || element.value === 0 || element.value === null || element.value === undefined){
      element.value = '';
      date = null;
    }else{
      date = element.value;
    }
    schedule[key]['Pay dates'][month] = date;
    refreshAccount();
  }

  function toggleConfirm(event){
    //Toggle dividend payment date confirmation flag
    event.preventDefault();
    const elementIDparts = event.target.id.split('-');
    const key = elementIDparts[0];
    const month = elementIDparts[1];
    const element = document.getElementById(event.target.id);
    const date = Number.parseInt(element.value);
    const cssClass = element.getAttribute('class');
    let confirmed = false;
    //Only allow confirmation of a valid date
    if(cssClass.includes('tentative') && Number.isInteger(date) && date > 0 && date <= DATE_LIMITS[month]){
      confirmed = true;
    }else if(cssClass.includes('confirmed')){
      confirmed = false;
    }else{
      //Bad input
      confirmed = false;
    }
    schedule[key]['Confirmations'][month] = confirmed;
    refreshAccount();
  }

  function bindButtonHandlers(){
    let button = document.getElementById('top-update-portfolio');
    button.addEventListener("click", updatePortfolio);
    button = document.getElementById('bottom-update-portfolio');
    button.addEventListener("click", updatePortfolio);
    button = document.getElementById('top-save-portfolio');
    button.addEventListener("click", savePortfolio);
    button = document.getElementById('bottom-save-portfolio');
    button.addEventListener("click", savePortfolio);
  }

  function bindSortHandlers(){
    for(let id of SORT_IDS){
      document.getElementById(id).addEventListener("click", sortRows);
    }
  }

  function sortRows(event){
    //Sort holding row order by selected column header or footer
    const sortParameters = SORT_PARAMETERS[event.target.id];
    sortTarget = sortParameters['Key'];
    const account = accounts[selectedAccount];
    holdings = account['Holdings'];
    rowOrder.sort(sortParameters["Method"]);
    refreshAccount();
  }

  function sortAscending(key1, key2){
    const entry1 = holdings[key1][sortTarget];
    const entry2 = holdings[key2][sortTarget];
    if(entry1 > entry2) {
	    return -1;
    } else {
	    return 1;
    }
  }

  function sortDescending(key1, key2){
    const entry1 = holdings[key1][sortTarget];
    const entry2 = holdings[key2][sortTarget];
    if(entry1 < entry2) {
	    return -1;
    } else {
	    return 1;
    }
  }

  function savePortfolio(){
    sendRequest('Controller', 'Save portfolio', portfolio);
  }

  function updatePortfolio(){
    sendRequest('Controller', 'Update portfolio');
  }

  function currencyFormat(number){
	  const currencyFormatter = new Intl.NumberFormat(
	    "en-US", {style:"currency", currency:"USD", minimumFractionDigits:2}
    );
	  return currencyFormatter.format(number);
  }
	  
  function percentFormat(number){
	  const percentFormatter = new Intl.NumberFormat("en-US", {style:"percent", minimumFractionDigits:2});
	  return percentFormatter.format(number);
  }

  function integerFormat(number){
	  const integerFormatter = new Intl.NumberFormat("en-US", {minimumFractionDigits:0});
	  return integerFormatter.format(number);
  }
  const MONTHS = [
    'january',
    'february',
    'march',
    'april',
    'may',
    'june',
    'july',
    'august',
    'september',
    'october',
    'november',
    'december'
  ];

  const DATE_LIMITS = {
    'january':31,
    'february':29,
    'march':31,
    'april':30,
    'may':31,
    'june':30,
    'july':31,
    'august':31,
    'september':30,
    'october':31,
    'november':30,
    'december':31 
  };

  const SORT_IDS = [
    'top-symbol',
    'top-name',
    'top-book',
    'top-market',
    'top-percent-book',
    'top-percent-market',
    'top-total-dividend',
    'top-percent-dividend',
    'bottom-symbol',
    'bottom-name',
    'bottom-book',
    'bottom-market',
    'bottom-percent-book',
    'bottom-percent-market',
    'bottom-total-dividend',
    'bottom-percent-dividend'
  ];

  const SORT_PARAMETERS = {
    'top-symbol':{'Method':sortDescending, 'Key':"Symbol"},
    'top-name':{'Method':sortDescending, 'Key':"Moniker"},
    'top-book':{'Method':sortAscending, 'Key':"Book value"},
    'top-market':{'Method':sortAscending, 'Key':"Market value"},
    'top-percent-book':{'Method':sortAscending, 'Key':"Percent book value"},
    'top-percent-market':{'Method':sortAscending, 'Key':"Percent market value"},
    'top-total-dividend':{'Method':sortAscending, 'Key':"Total dividend"},
    'top-percent-dividend':{'Method':sortAscending, "Key":"Percent dividend"},
    'bottom-symbol':{'Method':sortAscending, 'Key':"Symbol"},
    'bottom-name':{'Method':sortAscending, 'Key':"Moniker"},
    'bottom-book':{'Method':sortDescending, 'Key':"Book value"},
    'bottom-market':{'Method':sortDescending, 'Key':"Market value"},
    'bottom-percent-book':{'Method':sortDescending, 'Key':"Percent book value"},
    'bottom-percent-market':{'Method':sortDescending, 'Key':"Percent market value"},
    'bottom-total-dividend':{'Method':sortDescending, 'Key':"Total dividend"},
    'bottom-percent-dividend':{'Method':sortDescending, 'Key':"Percent dividend"}
  };
}

browser.runtime.onConnect.addListener(connect);


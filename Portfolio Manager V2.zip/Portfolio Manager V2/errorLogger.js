/*
 *  Log errors in download folder. Each error is stored in its own numbered file.
 */

function errorLogger(){
  const self = 'Error logger';
  let errorFolder, errorNumber = 0;
  Hub.register.call(self);
  
  function initialize(folderPath){
    errorFolder = folderPath;
    Hub.bindRequest.call(self, 'Set folder', setFolder);
    Hub.bindRequest.call(self, 'Log error', logError);
  }

  function setFolder(folderPath){
    //File path root is browser default download folder
    errorFolder = folderPath;
    errorNumber = 0;
  }

  function logError(error){
    errorNumber ++;
    browser.downloads.download(
      {url:URL.createObjectURL(new Blob([error + '\n' + error.stack], {type : 'text/html'})),
       filename:errorFolder + "/Errors/" + errorNumber.toString(),
       conflictAction:"overwrite"}
    ).catch(error => console.log(error));
  }
  return{initialize:initialize};
}


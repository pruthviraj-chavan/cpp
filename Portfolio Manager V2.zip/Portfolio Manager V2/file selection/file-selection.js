 /*
  * Content script for drag and drop file loading interface
  * Interface can be setup to accept single files of one or more mime types, or multiple files of one or more mime types
  */

function connect(backgroundPort){
  const port = backgroundPort;
  let self, senderName, multipleFile, singleMimeTypes, multipleMimeTypes;
  port.onMessage.addListener(messageHandler);
  document.addEventListener('dragover', dragItemsPresent);
  document.addEventListener('dragleave', dragItemsRemoved);
  document.addEventListener('drop', dragItemsDropped);

  function messageHandler(payload){
    if(payload === undefined){
      fail(Error('Undefined payload received by file selection content script'));
    }else{
      self = payload['self'];
      if(self === undefined){
        fail(Error("'self' not received by file selection content script"));
      }
      //Build dynamic parts of page
      if(payload['User prompt'] !== undefined){
        const userPrompt = document.getElementById('user-prompt');
        userPrompt.innerText = payload['User prompt'];
      }
      if(payload['Error message'] !== null){
        const userPrompt = document.getElementById('error-message');
        userPrompt.innerText = payload['error-message'];
      }
      if(payload['Multiple file'] !== undefined){
        multipleFile = payload['Multiple file'];
      }
      if(payload['Single mime types'] !== undefined){
        singleMimeTypes = payload['Single mime types'];
      }
      if(payload['Multiple mime types'] !== undefined){
        multipleMimeTypes = payload['Multiple mime types'];
      }
    }
  }
  
  function sendStatus(message, payload){
    port.postMessage(
      {
        'self':self,
        'Message type':'Status',
        'Message':message,
        'Payload':payload
      }
    );
  }
  
  function fail(error){
    port.postMessage(
      {
        'self':self,
        'Receiver name':'Error logger',
        'Message type':'Request',
        'Message':'Log error',
        'Payload':error
      }
    );
  }

  function checkFileTypes(items){
    let correctType = true;
    if(items.length > 1){
      if(multipleFile === false){
        correctType = false;
      }else{
     	  //Check if mime type matches acceptable multiple mime types
      	for(let index = 0; index < items.length; index ++){
      	  const item = items[index];
      		if(item.kind !== 'file' || multipleMimeTypes.includes(item.type) === false){
      			correctType = false;
      			break;
      		}
      	}
   	  }      
    }else{
   		//Check if mime type matches acceptable single mime types
   		const item = items[0];
   		if(item.kind === 'file' && singleMimeTypes.includes(item.type)){
    		correctType = true;
    	}else{
    		correctType = false;
    	} 	  
    }
	  //Change background to display file type status
	  if(correctType === true){
		  document.getElementById('file-drop-area').className = 'correct-type';
		  document.getElementById('error-message').className = 'hidden';
	  }else{
		  document.getElementById('file-drop-area').className = 'wrong-type';
		  const errorLabel = document.getElementById('error-message')
		  errorLabel.className = 'normal';
		  errorLabel.innerText = 'Invalid file type';
    }
    return correctType;
  }

  function dragItemsPresent(event){
	  //Prevent default item drag action
    event.preventDefault();
    //Change background to indicate correct or incorrect file type selection
    checkFileTypes(event.dataTransfer.items);
  }


  function dragItemsRemoved(event){
	  //Restore background colour
    document.getElementById('file-drop-area').className = 'item-removed';
  }

  function dragItemsDropped(event){
	  //Prevent default item drop action
    event.preventDefault();
    //Verify that correct item types have been dropped
    if(checkFileTypes(event.dataTransfer.items) === true){
      const items = event.dataTransfer.items, files = [];
      for(let index = 0; index < items.length; index ++){
        files.push(items[index].getAsFile());
      }
	    sendStatus('Files', files);
    }
  }

  function displayError(errorMessage){
    //Error detected with one or more files
    document.getElementById('file-drop-area').className = 'wrong-type';
    const errorLabel = document.getElementById('error-message');
    errorLabel.className = 'normal';
    errorLabel.innerText = errorMessage;
  }
}

browser.runtime.onConnect.addListener(connect);

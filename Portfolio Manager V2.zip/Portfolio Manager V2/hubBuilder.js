/*
 *  A hub is used as a communications link between autonomous client processes which use signals to asynchronously
 *  communicate with each other. The client has only one public method, initialize, and no public variables.
 *  All information flow into and out of the client is done by passing it a signal with attached payload.
 *  Although clients are secure against access by other clients, their methods are accessible by the hub which acts as
 *  a communication link between clients. The hub also provides methods for clients to determine if and how they will
 *  respond to signals from other clients and how they send signals to other clients.
 *  Transfers are done asynchronously using a Promise to put the transfer on an event loop as an intermediatary between
 *  client processes.
 *  The intent is to emulate an industrial automation line with autonomous workcells which communicate with each other
 *  using relatively simple signalling.
 *  Two signal types are used, status and request. The status signal is used when a process cannot know in advance which
 *  clients the signal will be sent to and is mainly used to communicate with multiple processes. Each process has a
 *  subscriber list of clients to which a particular status signal will be sent. The subscriber list is maintained by
 *  the hub using the bindStatus method. A process which wants to receive a particular status signal from another client
 *  will use the bindStatus method to add its name to the other client subscriber list and also to associate a method
 *  with the signal. The signal can be unbound by the receiving client simply by not specifying a method to bind to the
 *  signal.
 *  Request signals are used when the receiving client doesn't know in advance which clients will be sending it signals,
 *  but can associate signals with methods. The sending client passes the receiving client name to the hub which uses
 *  the client name to pass the signal to the correct client. Request signals are always sent only to one client.
 *  Each signal must be unique. To guarantee this a signal is created by concatenating a non unique message with either
 *  the sending or receiving client name. Because the name of a hub client receiving a request signal is known, the hub
 *  will concatenate the receiving client name to the message. The signal, message and payload are sent as one packet to
 *  the receiving client.
 *  For a status signal, the sending client is known and its name is concatenated with the message to create a unique
 *  signal. The receiving client knows in advance which signals it will receive and can set up the appropriate signal to
 *  method associations.
 *  A client is instantiated by registering its name with the hub. If the name has been previously registered, the hub
 *  will throw an error. This guarantees that all client names are unique and that signals derived from client names are
 *  also guaranteed to be unique.
 *  Clients can subscribe to receive messages from other clients that haven't yet been registered. The hub will set up
 *  the subscriber list for the sending client and when the sending client is registered, it will be associated with the
 *  subscriber list.
 *  If an attempt is made to send a signal to an unregistered client, an error will be thrown. This is easy to avoid by
 *  not starting any clients until all clients have been registered. A 'main' program can be used for registering and
 *  initializing all clients and then transmitting a signal to start the application.
 *  Because no calling context is passed from client to client or client to hub, 'this' is used primarily for passing
 *  hub client names. The 'this' parameter is always passed and rather than having it carry a default value which
 *  may cause confusion, as much as possible it is always assigned to a known object.
 *  Program sequencing should only be done by transmitting and responding to signals. This makes asynchronous operation
 *  very simple because a client can bind an unbind to any signal only when it is in an internal state where it is
 *  ready to respond to a signal.
 *  Signal flow can be determined and programmed in advance because associations between signals and concrete methods
 *  can be deferred past program startup if necessary. Hub and bridge clients can also be registered during runtime
 *  to dynamically change signal flow and program operation.
 *  Ideally, each client process should be relatively simple as is normal practice in industrial automation. It's better
 *  to have multiple simple processes with a minimal number of states than complex processes with multiple states.
 *  Program complexity and potential bugs grows exponentially with the number of states within a process.
 *  A punch press goes up and down. It may have multiple signals such as part presence, safety signals, hydraulic
 *  pressure, part loading actuators clear, and others, but only five main states. Stopped, going up, completely up,
 *  going down and completely down.
 *  Even though it may be part of a complex robotic workcell, the state machine governing its interaction with other
 *  parts of the workcell can be very simple and easily grasped and debugged. The same reasoning can be applied to
 *  other parts of the workcell and also to highly interactive event driven programs.
 */

function HubBuilder(){
  const clients = {};

  function register(){
    const instanceName = String(this);  //String may be sent in primitive form
    const client = clients[instanceName];
    if(client === undefined){
      clients[instanceName] = {'Active':true, 'Triggers':{}, 'Subscribers':{}};
    }else if(client['Active'] === true){
      throw Error('Client instance name ' + instanceName + ' previously assigned');
    }else{
      //client instance name has been set by another client registering as a receiver for that instance name
      client['Active'] = true;
    }
  }

  function transmitStatus(message, payload = null){
    //Send message to all clients registered to receive status messages from this client
    const instanceName = String(this);  //String may be sent in primitive form
    const receivers = clients[instanceName]['Subscribers'][instanceName + message];
    if(receivers !== undefined){
      for(let receiver of receivers){
        //Status messages must start with sender name
        send(receiver, instanceName + message, payload);
      }
    }
  }

  function transmitRequest(receiverName, message, payload = null){
    //Send a message only to the selected client
    //Request message must start with receiver name
    send(receiverName, receiverName + message, payload);
  }

  function broadcast(message, payload = null){
    //Broadcast request message to all instantiated clients
    const instanceName = String(this);  //String may be sent in primitive form
    for(let clientName in clients){
      if(clients[clientName]['Active'] === true && instanceName !== clientName){
        send(clientName, clientName + message, payload);
      }
    }
  }
  
  function send(receiverName, message, payload){
    const client = clients[receiverName];
    if(client === undefined){
      throw(Error('Transmit ' + message + ' to unknown ' + receiverName));
    }else if(client['Active'] !== true){
      throw(Error('Transmit ' + message + ' to uninstantiated ' + receiverName));
    }else{
      const packet = {
        receiver:receiverName,
        messageTag:message,
        payload:payload,
      }
      return new Promise(receive.bind(packet));
    }
  }
      
  function receive(){
    //Receive message from packet sent as 'this'
    const method = clients[this.receiver]['Triggers'][this.messageTag];
    if(method !== undefined && method !== null){
      method.call(this, this.payload);
    }
  }

  function bindStatus(senderName, message, method = null){
    //Associate status message with a method of this client, or null for disassociation from method
    const instanceName = String(this);  //String may be sent in primitive form
    if(method !== null){
      //This client must be instantiated, but sending client does not since none of its methods are used
      const senderclient = clients[senderName];
      if(senderclient === undefined){
        //Register client instance name as status message receiver without instantiating sending client
        const subscribers = {};
        subscribers[senderName + message] = Array(instanceName);
        const kingdom = {'Instance name':instanceName};
        clients[senderName] = {'Active':false, 'Triggers':{}, 'Subscribers':subscribers};
      }else{
        //Register this client as a receiver of this status message from the sending client
        //This client must be instantiated, but the sending client doesn't need to be instantiated
        if(clients[instanceName]['Active'] !== true){
          Error('Attempt to bind status to uninstantiated client: ' + instanceName);
        }else{
          const subscriptions = senderclient['Subscribers'][senderName + message];
          if(subscriptions !== undefined){
            //Other subscribers exist for this message
            if(subscriptions.indexOf(instanceName) < 0){
              subscriptions.push(instanceName);
            }
          }else{
            //First subscriber for this status message
            senderclient['Subscribers'][senderName + message] = Array(instanceName);
          }
        }
      }
      //Status messages must start with sender name
      clients[instanceName]['Triggers'][senderName + message] = method;
    }else{
      //Disassociate sender client status message with this client method
      const trigger = senderName + message;
      if(trigger in clients[instanceName]['Triggers']){
        delete clients[instanceName]['Triggers'][trigger];
      }
      //Unsubscribe from sender for this status message
      const senderclient = clients[senderName];
      if(senderclient !== undefined){
        const subscriptions = senderclient['Subscribers'][trigger];
        if(subscriptions !== undefined){
          const index = subscriptions.indexOf(instanceName);
          if(index >= 0){
            subscriptions.splice(index, 1);
          }
        }
      }
    }
  }
  
  function bindRequest(message, method = null){
    //Associate request message tag with a client method or null for dissassociation
    //Request messages must start with this receiver name
    const instanceName = String(this);  //String may be sent in primitive form
    clients[instanceName]['Triggers'][instanceName + message] = method;
  }

  function expunge(){
    //Remove client instance from database
    const instanceName = String(this);  //String may be sent in primitive form
    delete clients[instanceName];
    //Deregister this client as a status message receiver from all other clients
    for(let clientName in clients){
      subscribers = clients[clientName]['Subscribers'];
      for(let statusMessage in subscribers){
        let revisedSubscriptions = Array();
        let subscriptions = subscribers[statusMessage];
        //This client may be subscribed to multiple messages from a sender client
        for(let index in subscriptions){
          let subscription = subscriptions[index];
          if(subscription !== instanceName){
            revisedSubscriptions.push(subscription);
          }
        }
        subscriptions = revisedSubscriptions;
      }
    }
  }
  return {
    register:register,
    bindStatus:bindStatus,
    bindRequest:bindRequest,
    transmitStatus:transmitStatus,
    transmitRequest:transmitRequest,
    broadcast:broadcast,
    expunge:expunge,
  }
}

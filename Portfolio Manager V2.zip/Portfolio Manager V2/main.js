/*
 *  Setup hub and initial hub clients
 */
const Hub = HubBuilder();
const ErrorLogger = errorLogger();
ErrorLogger.initialize('Portfolio manager');
const Bridge = bridgeBuilder();
Bridge.initialize();
//The browser action icon is only control available to user when no user interface page is present
//Generally, clicking on the icon will regenerate the current user interface or make its tab active
const BrowserAction = browserAction();
const Controller = controller();
Controller.initialize();
//Start by uploading account files or previously saved portfolio
Hub.transmitRequest('Controller', 'Get portfolio');

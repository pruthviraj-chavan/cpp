//Read CSV file into array of rows with each row an array of columns
//Default column separation is either tab or comma
//A CSV row is is terminated by one or more of carriage return and or linefeed
//characters.
//Tab, comma, carriage return and linefeed characters must be enclosed in
//double quotes. Double quotes themselves are escaped by another double quote.
function readCSVfile(fileData, columnSeparators = "\t,"){
	const rows = [], lineEnds = "\n\r";
	//State machine used to parse data
	let state = "Read column", column = "", row = [];
	for(let index = 0; index < fileData.length; index++){
		let character = fileData[index];
		if(state === "Read column"){
			if(lineEnds.includes(character)){
				//End of current column and current row
				row.push(column), column = "";
				rows.push(row), row = [];
				state = "End of line";
			}else if(columnSeparators.includes(character)){
				//End of current column
				row.push(column), column = "";
			}else if(character === '"'){
				//Start of quoted string or escaped quote
				state = "Quote read";
			}else{
				column += character;
			}
		}else if(state === "Quote read"){
			column += character;
			if(character === '"'){
				//Escaped double quote character
				state = "Read column";
			}else{
				//Double quote indicates start of string
				state = "Read string";
			}
		}else if(state === "Read string"){
			if(character === '"'){
				//Start of escaped quote or end of quoted string
				state = "String quote";
			}else{
				column += character;
			}
		}else if(state === "String quote"){
			if(character === '"'){
				//Escaped double quote within a string
				column += character;
				state = "Read string";
			}else{
				//Quote was end of string
				if(lineEnds.includes(character)){
					//End of current column and current row
					row.push(column), column = "";
					rows.push(row), row = [];
				}else if(columnSeparators.includes(character)){
					//End of current column
					row.push(column), column = "";
				}else if(character === '"'){
					//Start of quoted string or escaped quote
					state = "Quote read";
				}else{
					column += character;
					state = "Read column";
				}
			}
		}else if(state === "End of line"){
			//Skip multiple line end characters
			if(lineEnds.includes(character) === false){
				if(columnSeparators.includes(character)){
					//End of current column
					row.push(column), column = "";
					state = "Read column";
				}else if(character === '"'){
					//Start of escaped quote or start of quoted string
					state = "Quote read";
				}else{
					column += character;
					state = "Read column";
				}				
			}
		}
	}
	//Clean up any loose ends
	if(column.length > 0){
		row.push(column);
	}
	if(row.length > 0){
		rows.push(row);
	}
	return(rows);
}


function numerify(numberString){
	//Strip out non-numeric characters such as "$" and convert to float
	if (numberString === undefined){
		return;
	}
	let cleanedNumber = "", numerics = "+-.0123456789";
	for (let index in numberString){
		let character = numberString[index];
		if(numerics.includes(character)){
			cleanedNumber += character;
		}
	}
	return parseFloat(cleanedNumber);
}

function currencyFormat(number){
	const currencyFormatter = new Intl.NumberFormat(
	  "en-US", {style:"currency", currency:"USD", minimumFractionDigits:2}
  );
	return currencyFormatter.format(number);
}
	
function percentFormat(number){
	const percentFormatter = new Intl.NumberFormat("en-US", {style:"percent", minimumFractionDigits:2});
	return percentFormatter.format(number);
}

function integerFormat(number){
	const integerFormatter = new Intl.NumberFormat("en-US", {minimumFractionDigits:0});
	return integerFormatter.format(number);
}

function restore(value){
	//Restore escaped characters
	let escapedCharacters = {
		   "&lt":"<", "&#60":"<", "&gt":">", "&#62":">", "&amp":"&", "&#38":"&",
		   "&apos":"'", "&#39":"'", "&quot":'"', "&#34":'"', "&Agrave":"À",
		   "&agrave":"à", "&Acirc":"Â", "&acirc":"â", "&AElig":"Æ", "&aelig":"æ",
		   "&Ccedil":"Ç", "&ccedil":"ç", "&Egrave":"È", "&egrave":"è", "&Eacute":"É",
		   "&eacute":"é", "&Ecirc":"Ê", "&ecirc":"ê", "&Euml":"Ë", "&euml":"ë",
		   "&Icirc":"Î", "&icirc":"î", "&Iuml":"Ï", "&iuml":"ï", "&Ocirc":"Ô",
		   "&ocirc":"ô", "&OElig":"Œ", "&oelig":"œ", "&Ugrave":"Ù", "&ugrave":"ù",
		   "&Ucirc":"Û", "&ucirc":"û", "&Uuml":"Ü", "&uuml":"ü", "&laquo":"«",
		   "&raquo":"»"
		};
	let escapeStart = 0, escapeEnd, escapeString, left, middle, right;
	while (true){
		escapeStart = value.indexOf("&", escapeStart)
		if(escapeStart >= 0){
	    escapeEnd = value.indexOf(";", escapeStart)
	    if(escapeEnd >= 0){
        left = value.substring(0, escapeStart);
        right = value.substring(escapeEnd + 1);
        escapeString = value.substring(escapeStart, escapeEnd);
        escapeStart++;
        middle = escapedCharacters[escapeString];
        if(middle === undefined){
          //Unknown escape character
          value = left + escapeString + right;
        } else {
          value = left + middle + right;
        }
	    } else {
        //Invalid document, escape start without escape end
        return;
      }
		} else {
	    //All done
	    break;
	  }
	}
	return value;
}

function wordToBytes(word, bigEndian = false){
	//Output 32 bit word as array of bytes
	const output = [];
	for (let byteShift = 0, mask = 0xFF; byteShift < 32; byteShift += 8, mask <<= 8){
		const byte = (word & mask) >>> byteShift;
		if(bigEndian === false){
			output.push(byte);
		} else {
			output.unshift(byte);
		}
	}
	return output;
}

function hexAsciiToBytes(hexString){
	//Convert ASCII coded hex string to array of bytes
	const output = [];
	for (let offset = 0; offset < hexString.length; offset += 2){
		output.push(parseInt(hexString.slice(offset, offset + 2), 16));
	}
	return output;
}

function hexASCIItoWorm(hexString){
	//Copy ASCII coded hex string to worm
	const output = new Worm();
	for (let offset = 0; offset < hexString.length; offset += 2){
		output.pushByte(parseInt(hexString.slice(offset, offset + 2), 16));
	}
	return output;
}

function asciiToWorm(asciiString){
	//Copy ASCII coded hex string to worm
	const output = new Worm();
	for (let index in asciiString){
		output.pushByte(asciiString.charCodeAt(index));
	}
	return output;
}

function asciiToBytes(asciiString){
	//Convert ASCII string to array of bytes
	const output = [];
	for (let index in asciiString){
		output.push(asciiString.charCodeAt(index));
	}
	return output;
}

function integerToHexASCII(integer, signed = false){
	//Convert integer to hex ASCII string
	//Show as signed number if signed parameter is true
	let ascii, hexASCII = "";
	if(signed === false){
		//Split integer to eliminate affect of sign bit
		let lowWord = (integer & 0x0000FFFF).toString(16);
		let highWord = (integer >>> 16).toString(16);
		if(highWord !== "0"){
			//Low word may require leading zero padding
			ascii = highWord + lowWord.padStart(4, "0");
		} else {
			ascii = lowWord;
		}
	} else {
		ascii = integer.toString(16);
	}
	//Add leading zero for aesthetics
	if((ascii.length % 2) === 0){
		hexASCII += ("0x" + ascii.toUpperCase());
	} else {
		hexASCII += ("0x0" + ascii.toUpperCase());
	}
	return hexASCII;
}

function wormToHexASCII(worm, signed = false){
	//Convert worm contents to hex ASCII string
	//Show as signed number if signed parameter is true
	let hexASCII = integerToHexASCII(worm.getByte(0));
	for (offset = 1; offset < worm.byteLength; offset ++){
		hexASCII += (", " + integerToHexASCII(worm.getByte(offset), signed));
	}
	return hexASCII;
}

function integersToHexASCII(integers, signed = false){
	//Convert array of integers to hex ASCII string
	//Show as signed number if signed parameter is true
	let hexASCII = integerToHexASCII(integers[0]);
	for (index = 1; index < integers.length; index ++){
		hexASCII += (", " + integerToHexASCII(integers[index], signed));
	}
	return hexASCII;
}

function arrayBufferToBytes(buffer){
	//Convert array buffer to array of bytes
	const dataView = new DataView(buffer), output = [];
	for (let offset = 0; offset < dataView.byteLength; offset ++){
		output.push(dataView.getUint8(offset));
	}
	return output;
}

function arrayBufferToHexASCII(buffer){
	//Convert array buffer to hex ASCII string
	const dataView = new DataView(buffer);
	let hexASCII = "";
	for(let offset = 0; offset < dataView.byteLength; offset ++){
		if(hexASCII.length > 0){
			hexASCII += ", ";
		}
		let ascii = dataView.getUint8(offset).toString(16).toUpperCase();
		if((ascii.length % 2) === 0){
			hexASCII += ("0x" + ascii);
		} else {
			hexASCII += ("0x0" + ascii);
		}
	}
	return hexASCII;
}

function bytesToDataView(bytes){
	//Convert array of bytes to DataView of an array buffer
	const dataView = new DataView(new ArrayBuffer(bytes.length));
	for(let index in bytes){
		dataView.setUint8(index, bytes[index]);
	}
	return dataView;
}
